#ifndef OPERATINGSYSTEM_H
#define OPERATINGSYSTEM_H

#include "ComputerSystem.h"
#include <stdio.h>

#define SUCCESS 1
#define PROGRAMDOESNOTEXIST -1
#define PROGRAMNOTVALID -2

#define NOFREEENTRY -3
#define TOOBIGPROCESS -4

#define NOPROCESS -1

#define SLEEPINGQUEUE 0 // -- V2 - 5c -----------------------------------------
#define ARRIVALQUEUE 0	// -- V3 - 1b -----------------------------------------

// Number of queues of ready to run processes, initially one queue...
// -- V1 - 11a ----------------------------------------------------------------
#define NUMBEROFQUEUES 2

// Partitions and holes configuration file name definition
#define MEMCONFIG	  // -- V4 - 5a -------------------------------------------
#define MEMORYFULL -5 // -- V4 - 6d--------------------------------------------

enum TypeOfReadyToRunProcessQueues
{
	USERPROCESSQUEUE,
	DAEMONSQUEUE
};
// enum TypeOfReadyToRunProcessQueues { ALLPROCESSESQUEUE };

// Contains the possible type of programs
enum ProgramTypes
{
	USERPROGRAM = 100,
	DAEMONPROGRAM
};

// Enumerated type containing all the possible process states
enum ProcessStates
{
	NEW,
	READY,
	EXECUTING,
	BLOCKED,
	EXIT
};

// Enumerated type containing the list of system calls and their numeric identifiers
enum SystemCallIdentifiers
{
	SYSCALL_END = 3,
	SYSCALL_PRINTEXECPID = 5,
	SYSCALL_YIELD = 4, // -- V1 - 12 ------------------------------------------
	SYSCALL_SLEEP = 7  // -- V2 - 5f ------------------------------------------
};

// A PCB contains all of the information about a process that is needed by the OS
typedef struct
{
	int busy;
	int initialPhysicalAddress;
	int processSize;
	int state;
	int priority;
	int programListIndex;
	int queueID; // -- V1 - 11a --

	// -- V1 - 13 -------------------------------------------------------------
	int copyOfSPRegister;
	int copyOfPCRegister;
	unsigned int copyOfPSWRegister;

	int copyAccumulator;

	int copyA;
	int copyB;

	// -- V2 - 5a -------------------------------------------------------------
	int whenToWakeUp;

} PCB;

// These "extern" declaration enables other source code files to gain access
// to the variable listed

// Functions prototypes
void OperatingSystem_Initialize(int);
void OperatingSystem_InterruptLogic(int);
int OperatingSystem_ShortTermScheduler();
void OperatingSystem_Dispatch(int);
#endif
